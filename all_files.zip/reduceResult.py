import argparse

def reduce_file_name(compelxity, noise, index):
    return "reduce_file_complexity_%d_%d_%d.txt" % (complexity, noise, index)


"""Reduce output files"""

if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    # Input variables
    # parser.add_argument("-nodes","--n_nodes", default = 1, help = "The number of workers", type = int)
    # parser.add_argument("-epochs","--epochs", default = 200, help = "The number of epochs", type = int)
    # parser.add_argument("-num","--n_iters", default = 1, help = "The number of workers", type = int)
    # parser.add_argument("-numHid","--numHid", help = "The dimension of hitting dimensions", type = int)
    # parser.add_argument("-trainpath","--trainpath", help = "The training data", type=str)
    # parser.add_argument("-testpath","--testpath", help = "The test data", type=str)
        
    args = parser.parse_args()
    
    complexity_range = range(1,9)
    noise_range = range(10,16)  
    index_range = range(args.n_iters)

    final_result_file_names = [["final_result_%d_%d.txt" % (complexity , noise) for noise in noise_range] for complexity in complexity_range]

    # final_result_sums = [[0.0]*6]*8
    # final_result_maxs = [[0.0]*6]*8
    # final_result_mins = [[0.0]*6]*8

    for complexity in complexity_range:
        for noise in noise_range:
            final_result_sum = 0.0
            final_result_max = 0.0
            final_result_min = 0.0
            for index in index_range:
                f = open(reduce_file_name(complexity, noise, index), 'r')
                result = float(f.read().split[-1])
                f = close()
                final_result_sum += result
                if result > final_result_sum:
                    final_result_max = result
                if result < final_result_min:
                    final_result_min = result
            final_result_avg = final_result_sum / float(args.n_iters)
            f = open(final_result_file_names[complexity - 1][noise - 10], 'w')
            f.write("Result for %d iterations %d complexity level .%d noise level" % (args.n_iters, complexity, noise))
            f.write("maximum: " + str(final_result_max) + "\n")
            f.write("minimum: " + str(final_result_min) + "\n")
            f.write("average: " + str(final_result_sum) + "\n")
            f.close()
